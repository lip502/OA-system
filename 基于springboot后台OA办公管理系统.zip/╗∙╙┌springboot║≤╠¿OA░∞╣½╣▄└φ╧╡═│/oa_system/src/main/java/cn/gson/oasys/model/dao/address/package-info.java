
/**
 * 通讯录
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.dao.address;