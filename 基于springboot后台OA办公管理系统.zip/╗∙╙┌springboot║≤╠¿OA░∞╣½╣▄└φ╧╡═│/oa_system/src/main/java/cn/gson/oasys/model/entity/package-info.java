
/**
 * 实体类
 * @author luoxiang
 *
 */
package cn.gson.oasys.model.entity;