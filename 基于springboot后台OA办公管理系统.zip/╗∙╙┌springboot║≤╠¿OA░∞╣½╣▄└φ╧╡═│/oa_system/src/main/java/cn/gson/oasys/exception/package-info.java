
/**
 * 异常处理
 * 自定义异常
 * @author luoxiang
 *
 */
package cn.gson.oasys.exception;