

/**
 * 通讯录service
 * @author luoxiang
 *
 */
package cn.gson.oasys.services.address;